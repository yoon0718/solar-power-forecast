const Header = () => {
  return (
    <div>
      <header id="title">
        <a href="/">
          <img src="../img/sunicon.png" id="icon"></img>
        </a>
      </header>
    </div>
  );
};

export default Header;
