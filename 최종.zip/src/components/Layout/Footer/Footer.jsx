const Footer = () => {
  return (
    <div>
      <footer>
        <h5 id="path"> 광주광역시 광산구 소촌로 152번길 37</h5>
        <br />
        <h5>
          <a href="https://github.com/yoon0718/solar-power-forecast" target="_blank">
            https://github.com/yoon0718/solar-power-forecast
          </a>
        </h5>
        <h5>Github ID : yoon0718(PL), Jssong-ho, raincross7, portk, azure0321</h5>
      </footer>
    </div>
  );
};

export default Footer;
