// npm install react-table
// npm install react-data-table-component
// npm install chartjs-plugin-datalabels
// npm install react-chartjs-2
// npm i react-modal
// npm i axios
//npm install chartjs-plugin-zoom

import './App.css';
import Layout from './components/Layout/Layout';

const App = () => {
  return (
    <div className="App">
      <Layout></Layout>
    </div>
  );
};
export default App;
